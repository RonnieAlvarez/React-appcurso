import React from "react";
import ItemDetailContainer from "./ItemDetailContainer";

export const MainDetail = () => {

  return (
    <div className="App">
    <ItemDetailContainer/>
    
    </div>
  );
};

export default Main;


